# Powertec Training — Full Integrated Curriculum V4

Static multi-file curriculum build. It deliberately separates content into module, lesson, cycle, scenario, evidence, reference and governance files rather than embedding the programme in one JavaScript bundle.

This build is educational/simulation content, not live operational instruction and not a multi-user production backend.
